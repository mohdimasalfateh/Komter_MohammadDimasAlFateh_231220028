import threading
import time
import random

# Jumlah filsuf dan garpu
N = 5
garpu = [threading.Lock() for _ in range(N)]

def filsuf(nama, kiri, kanan):
    for i in range(3):  # masing-masing makan 3 kali
        print(f"{nama} sedang berpikir...")
        time.sleep(random.uniform(0.5, 1.5))

        print(f"{nama} lapar dan mencoba mengambil garpu kiri...")
        with kiri:
            print(f"{nama} mendapat garpu kiri.")
            print(f"{nama} mencoba mengambil garpu kanan...")
            dengan_sukses = kanan.acquire(timeout=1)

            if dengan_sukses:
                print(f"{nama} mendapat garpu kanan dan mulai makan ")
                time.sleep(random.uniform(0.8, 1.2))
                print(f"{nama} selesai makan dan meletakkan kedua garpu.\n")
                kanan.release()
            else:
                print(f"{nama} tidak mendapat garpu kanan, meletakkan garpu kiri.\n")

# Membuat dan menjalankan thread untuk setiap filsuf
filsuf_list = []
for i in range(N):
    t = threading.Thread(
        target=filsuf,
        args=(f"Filsuf-{i+1}", garpu[i], garpu[(i + 1) % N])
    )
    filsuf_list.append(t)
    t.start()

# Menunggu semua selesai
for t in filsuf_list:
    t.join()

print("Semua filsuf telah selesai makan tanpa deadlock ")